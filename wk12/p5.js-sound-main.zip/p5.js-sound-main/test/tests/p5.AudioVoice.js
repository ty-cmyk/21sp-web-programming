describe('p5.AudioVoice', function () {
  it('can be created and disposed', function () {
    const av = new p5.AudioVoice();
    av.dispose();
  });
});
