class Signal {
  constructor() {
    console.warn('p5.Signal is deprecated , Use Tone.js Signal instead ');
  }
}

export default Signal;
